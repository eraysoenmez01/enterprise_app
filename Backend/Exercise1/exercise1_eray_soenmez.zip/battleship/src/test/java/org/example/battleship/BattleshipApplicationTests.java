package org.example.battleship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BattleshipApplicationTests {

    @Test
    void contextLoads() {
    }

}
